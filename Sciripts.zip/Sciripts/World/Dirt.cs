using UnityEngine;

[CreateAssetMenu(fileName = "Dirt", menuName = "Scriptable Objects/Dirt")]
public class Dirt : ScriptableObject
{
    
}
